const etapas = [
    {
        titulo: "📦 Coletando produto",
        descricao: "O produto foi coletado pela agência dos Correios e está aguardando processamento."
    },
    {
        titulo: "🚚 Em trânsito",
        descricao: "O produto saiu da unidade de origem e está em transporte para a próxima unidade operacional."
    },
    {
        titulo: "🏢 Chegou na unidade",
        descricao: "O produto chegou na unidade de distribuição e está em processamento interno."
    },
    {
        titulo: "📤 Saiu para entrega",
        descricao: "O produto saiu para entrega ao destinatário. Aguarde, em breve será entregue."
    },
    {
        titulo: "✅ Entregue",
        descricao: "O produto foi entregue ao destinatário com sucesso!"
    }
];

function iniciarRastreamento() {
    const codigo = document.getElementById("codigo").value.trim();
    const barra = document.querySelectorAll(".etapa");
    const statusTexto = document.getElementById("status");
    const erro = document.getElementById("mensagemErro");

    erro.innerText = "";
    statusTexto.innerText = "Status: Aguardando...";

    if (codigo === "" || codigo.length < 8) {
        erro.innerText = "Por favor, digite um código de rastreio válido.";
        return;
    }

    barra.forEach(etapa => etapa.classList.remove("ativo"));

    let etapaAtual = 0;

    statusTexto.innerText = `Status: ${etapas[etapaAtual].titulo}\n${etapas[etapaAtual].descricao}`;
    atualizarBarra(barra, etapaAtual);

    const intervalo = setInterval(() => {
        etapaAtual++;

        if (etapaAtual < etapas.length) {
            statusTexto.innerText = `Status: ${etapas[etapaAtual].titulo}\n${etapas[etapaAtual].descricao}`;
            atualizarBarra(barra, etapaAtual);
        } else {
            clearInterval(intervalo);
            statusTexto.innerText = `Status: ✅ Entregue\n${etapas[etapaAtual - 1].descricao}`;
        }
    }, 86400000);
}

function atualizarBarra(barra, etapaAtual) {
    barra.forEach((elemento, index) => {
        if (index <= etapaAtual) {
            elemento.classList.add("ativo");
        } else {
            elemento.classList.remove("ativo");
        }
    });
}